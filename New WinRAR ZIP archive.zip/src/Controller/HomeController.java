package Controller;

import Model.Homedata;
import javax.swing.table.DefaultTableModel;

public class HomeController {
// Method to get data from Data class
    public DefaultTableModel getData() {
        return new Homedata().getData();
    }
    public void datapasing_1(String itemname, String itemsize , int price) {
        new Homedata().passing_1(itemname,itemsize, price);
    }

    public void datapasing(int aa, int cd, int ef) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
