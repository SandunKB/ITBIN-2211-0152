/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class Homedata {
    // Method to retrieve data from the database
public DefaultTableModel getData() {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        DefaultTableModel model = new DefaultTableModel();
        
        try {
            con = DBConnection.conn();
            String sqlquery = "SELECT * FROM items";
            pst = con.prepareStatement(sqlquery);
            rs = pst.executeQuery();
            
            model.addColumn("itemname");
            model.addColumn("itemsize");
            model.addColumn("price");

            while (rs.next()) {
                Object[] row = new Object[3];
                for (int i = 0; i < 3; i++) {
                    row[i] = rs.getObject(i + 1);
                }
                model.addRow(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error closing resources: " + e.getMessage());
            }
        }
        return model;
    }

    /**
     *
     * @param itemname
     * @param itemsize
     * @param price
     */
    public void passing_1(String itemname, String itemsize, int price) {
        Connection con = null;
        PreparedStatement pst = null;
        
        try {
            con = DBConnection.conn();
            String sqlquery = "INSERT INTO items(itemname, itemsize, price) VALUES (?, ?, ?)";
            pst = con.prepareStatement(sqlquery);
            pst.setString(1, itemname);
            pst.setString(2, itemsize);
            pst.setInt(3, price);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Inserted Successfully");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        } finally {
            try {
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error closing resources: " + e.getMessage());
            }
        }
    }
    

    public void updatehomedata(String itemname, String itemsize, int price) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getitemname() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setiemsize(String name) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setprice(String address) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
